package com.example.gifticon_management;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class ViewPagerAdapter extends FragmentPagerAdapter {

    private ArrayList<Fragment> fragments;
    String[] tabName = {"사용전","사용후"};

    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
        fragments = new ArrayList<>();
        //프래그먼트가 담겨있는 arrayList에 해당 프래그먼트를 넣어준다.
        fragments.add(new UseBeforeFragment());
        fragments.add(new UseAfterFragment());
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @NonNull
    @Override
    public CharSequence getPageTitle(int position){
        return tabName[position];
    }
}
